#include <cstdlib>
#include <iostream>
#include <ctime>
#include<vector>
#include<map>
#include "average.h"



int main(){
int loop=0;
int student=0;
int studentcount=1;
std::string name="AAA";
std::vector<Average> avg;
std::map<std::string,Average> AVG;
avg.push_back({});

do{

for(int i=0;i<32;i++) std::cout << "=";
std::cout<<std::endl;
std::cout<<"      AVERAGE CALCULATOR!"<<std::endl;
for(int i=0;i<32;i++) std::cout << "=";
std::cout<<std::endl;
std::cout <<"The current student is "<<student<<std::endl;
std::cout << "The current average is " << avg[student] << std::endl;
std::cout<< "\n1 - Enter a new value\n2 - Auto enter a random value\n5 - Create a new student\n6 - Select an existing student\n9 - Clear the calculator for this student\n0 - Exit\n\nCommand? " ;
std::cin>>loop;
if(loop==1){
  std::cout<<"Value: ";
  std::cin>>avg[student];
}else if (loop==2)
  avg[student]+= static_cast <float> (rand()) / static_cast <float> (RAND_MAX) * 100;
else if (loop==5){
avg.push_back({});
student=avg.size()-1;
studentcount++;
}
else if (loop==6){
std::cout<<"Select a student: ";
int temp;
std::cin>>temp;
if(temp<studentcount)
  student=temp;
else
  std::cout<<"\nStudent does not exist\n"<<std::endl;

}
else if(loop==9){
  avg[student]+=-1;
  std::cout<<"\nAverage deleted\n"<<std::endl;
}


}while(loop);
return 0;
}
