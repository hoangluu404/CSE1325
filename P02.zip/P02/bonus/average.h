#ifndef Avg_H
#define Avg_H
#include <cstdlib>
#include <iostream>
#include <ctime>

class Average{
public:
  Average();
  friend std::ostream& operator<<(std::ostream& ost, Average& average);
  friend std::istream& operator>>(std::istream& ist, Average& average);
  void operator+=(double value);
private:
  double _sum;
  int _value;
};

#endif