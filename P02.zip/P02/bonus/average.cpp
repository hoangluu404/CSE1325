#include "average.h"



Average::Average(): _sum{0}, _value{0} {};
std::ostream& operator<<(std::ostream& ost, Average& average){
  if(average._value!=0)
    ost << average._sum / average._value;
  else
    ost << "undefined";
return ost;
}
std::istream& operator>>(std::istream& ist, Average& average){  
  double value;
  ist>>value;
  average._sum = average._sum + value;
  average._value = average._value + 1;
  return ist;
}
void Average::operator+=(double value){
  this->_sum = this->_sum + value;
  this->_value = this->_value +1;
  if(value<0){
    this->_sum = 0;
    this->_value = 0;
  }
}


