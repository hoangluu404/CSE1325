#include <cstdlib>
#include <iostream>
#include <ctime>
#include "average.h"



int main(){
int loop=0;
Average avg;
do{
for(int i=0;i<32;i++) std::cout << "=";
std::cout<<std::endl;
std::cout<<"      AVERAGE CALCULATOR!"<<std::endl;
for(int i=0;i<32;i++) std::cout << "=";
std::cout<<std::endl;

std::cout << "The current average is " << avg << std::endl;
std::cout<< "\n1 - Enter a new value\n2 - Auto generate a random value\n9 - Clear the calculator\n0 - Exit\n\nCommand? " ;
std::cin>>loop;
if(loop==1){
  std::cout<<"Value: ";
  std::cin>>avg;
  

}else if (loop==2)
  avg+= static_cast <float> (rand()) / static_cast <float> (RAND_MAX) * 100;
else if(loop==9){
  avg+=-1;
  
}


}while(loop);
return 0;
}
